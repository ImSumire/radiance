#pragma once


/*
    Declaration of the State struct, which will hold data shared across the
    entire game logic. You can add fields here as needed for your game, for
    example:

    typedef struct State {
        int playerScore;
        float playerPositionX;
        float playerPositionY;
    } State;
*/
typedef struct State {
    // For now, the struct is empty, but you can extend it as needed.
} State;
