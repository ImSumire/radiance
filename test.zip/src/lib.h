#pragma once

#include <raylib.h>

#include "common/state.h"


// Called once at startup to initilize the state
void init(State* state) {}

// Update the state each frame
void update(State* state) {}

// Responsible for drawing the state each frame
void render(State* state) {
    BeginDrawing();
        ClearBackground(BLACK);
        DrawText("Welcome!", 40, 40, 32, WHITE);
        DrawText("Modify the `render` function of `src/lib.h`, then save to see the changes.", 40, 90, 20, WHITE);
        DrawText("No need to close the current window or recompile!", 40, 110, 20, WHITE);
    EndDrawing();
}

// Cleanup function, called once at shutdown to free the memory
void drop(State* state) {}
